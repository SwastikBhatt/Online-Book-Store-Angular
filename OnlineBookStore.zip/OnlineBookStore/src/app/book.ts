export class Book {
    bookCategory:string;
	bookName:string;
	authorName:string;
	ISBN:string;
	publishDate:string;
	bookImage:string;
	bookPrice:number;
	bookDescription:string;
}
