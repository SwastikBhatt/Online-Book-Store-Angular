import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { Router } from '@angular/router';
import { BookService } from '../book.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  books: Book[] = [];

  constructor(private router: Router, private bookService: BookService) {
  }

  ngOnInit() {
    this.bookService.getBooks().subscribe(data => {
      console.log(data);
      this.books = data;
    },
      err => { console.log(err) }
    );
  }

  deleteBook(book: Book) {
    this.bookService.deleteBook(book).subscribe(data => {
      this.books = this.books.filter(u => u !== book);
    })
  }

}
