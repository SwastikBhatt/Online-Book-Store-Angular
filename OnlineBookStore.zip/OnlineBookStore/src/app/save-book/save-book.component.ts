import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { Router } from '@angular/router';
import { BookService } from '../book.service';

@Component({
  selector: 'app-save-book',
  templateUrl: './save-book.component.html',
  styleUrls: ['./save-book.component.css']
})
export class SaveBookComponent {
  
  book: Book = new Book();

  constructor(private router: Router, private bookService: BookService) {
  }

  ngOnInit() {
  }

  createBook() {
    this.bookService.createBook(this.book).subscribe(data => {
      alert("User created successfully");
    });
  }

}
