import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { SaveBookComponent } from './save-book/save-book.component';
import { UpdateBookComponent } from './update-book/update-book.component';
import { ListAllBooksComponent } from './list-all-books/list-all-books.component';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: AppComponent },
  { path: 'saveBook', component: SaveBookComponent },
  { path: 'updateBook', component: UpdateBookComponent },
  { path: 'listBooks', component: ListAllBooksComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
