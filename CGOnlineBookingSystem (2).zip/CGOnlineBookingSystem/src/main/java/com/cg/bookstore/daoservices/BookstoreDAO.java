package com.cg.bookstore.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bookstore.beans.Books;


public interface BookstoreDAO  extends JpaRepository<Books, String>{

}
