package com.cg.bookstore.stepdefinitions;

import org.openqa.selenium.WebDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SaveBookDetailsStepDefinition {
	
	private WebDriver driver;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver.exe");
	}
	
	
	@Given("^user is accessing AddBook Page$")
	public void user_is_accessing_AddBook_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit request after entering valid set of information$")
	public void user_is_trying_to_submit_request_after_entering_valid_set_of_information() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Your Book Details has successfully been register$")
	public void your_Book_Details_has_successfully_been_register() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit data without 'bookName'$")
	public void user_is_trying_to_submit_data_without_bookName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Please fill out this field\\.'$")
	public void please_fill_out_this_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit data without entering 'authorName'$")
	public void user_is_trying_to_submit_data_without_entering_authorName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit data without entering 'ISBN'$")
	public void user_is_trying_to_submit_data_without_entering_ISBN() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit data without entering 'publishDate'$")
	public void user_is_trying_to_submit_data_without_entering_publishDate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit data without entering 'bookImage'$")
	public void user_is_trying_to_submit_data_without_entering_bookImage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit data without entering 'bookPrice'$")
	public void user_is_trying_to_submit_data_without_entering_bookPrice() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit data without entering 'bookDescription'$")
	public void user_is_trying_to_submit_data_without_entering_bookDescription() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user is trying to submit data without entering 'bookCategory'$")
	public void user_is_trying_to_submit_data_without_entering_bookCategory() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
