package com.cg.bookstore.aspect;

public class BookstoreExceptionAspect {

}
