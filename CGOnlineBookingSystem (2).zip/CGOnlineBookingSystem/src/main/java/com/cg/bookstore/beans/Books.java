package com.cg.bookstore.beans;

import java.sql.Blob;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Books {
	private Category bookCategory;
	private String bookName;
	private String authorName;
	@Id
	private String ISBN;
	private Date publishDate;
	private Blob bookImage;
	private double bookPrice;
	private String bookDescription;
	public Books() {
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ISBN == null) ? 0 : ISBN.hashCode());
		result = prime * result + ((authorName == null) ? 0 : authorName.hashCode());
		result = prime * result + ((bookCategory == null) ? 0 : bookCategory.hashCode());
		result = prime * result + ((bookDescription == null) ? 0 : bookDescription.hashCode());
		result = prime * result + ((bookImage == null) ? 0 : bookImage.hashCode());
		result = prime * result + ((bookName == null) ? 0 : bookName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(bookPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((publishDate == null) ? 0 : publishDate.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "Books [bookCategory=" + bookCategory + ", bookName=" + bookName + ", authorName=" + authorName
				+ ", ISBN=" + ISBN + ", publishDate=" + publishDate + ", bookImage=" + bookImage + ", bookPrice="
				+ bookPrice + ", bookDescription=" + bookDescription + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Books other = (Books) obj;
		if (ISBN == null) {
			if (other.ISBN != null)
				return false;
		} else if (!ISBN.equals(other.ISBN))
			return false;
		if (authorName == null) {
			if (other.authorName != null)
				return false;
		} else if (!authorName.equals(other.authorName))
			return false;
		if (bookCategory != other.bookCategory)
			return false;
		if (bookDescription == null) {
			if (other.bookDescription != null)
				return false;
		} else if (!bookDescription.equals(other.bookDescription))
			return false;
		if (bookImage == null) {
			if (other.bookImage != null)
				return false;
		} else if (!bookImage.equals(other.bookImage))
			return false;
		if (bookName == null) {
			if (other.bookName != null)
				return false;
		} else if (!bookName.equals(other.bookName))
			return false;
		if (Double.doubleToLongBits(bookPrice) != Double.doubleToLongBits(other.bookPrice))
			return false;
		if (publishDate == null) {
			if (other.publishDate != null)
				return false;
		} else if (!publishDate.equals(other.publishDate))
			return false;
		return true;
	}
	
	public Books(Category bookCategory, String bookName, String authorName, String iSBN, Date publishDate,
			double bookPrice, String bookDescription) {
		super();
		this.bookCategory = bookCategory;
		this.bookName = bookName;
		this.authorName = authorName;
		ISBN = iSBN;
		this.publishDate = publishDate;
		this.bookPrice = bookPrice;
		this.bookDescription = bookDescription;
	}

	public Books(Category bookCategory, String bookName, String authorName, String iSBN, Date publishDate,
			Blob bookImage, double bookPrice, String bookDescription) {
		super();
		this.bookCategory = bookCategory;
		this.bookName = bookName;
		this.authorName = authorName;
		ISBN = iSBN;
		this.publishDate = publishDate;
		this.bookImage = bookImage;
		this.bookPrice = bookPrice;
		this.bookDescription = bookDescription;
	}
	public Category getBookCategory() {
		return bookCategory;
	}
	public void setBookCategory(Category bookCategory) {
		this.bookCategory = bookCategory;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public Date getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}
	public Blob getBookImage() {
		return bookImage;
	}
	public void setBookImage(Blob bookImage) {
		this.bookImage = bookImage;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	public String getBookDescription() {
		return bookDescription;
	}
	public void setBookDescription(String bookDescription) {
		this.bookDescription = bookDescription;
	}
}
