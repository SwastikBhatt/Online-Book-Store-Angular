package com.cg.bookstore.beans;

public enum Category {
	Programming, Action, Thriller, Romantic, Crime, Mystery, Religious, Educational
}
