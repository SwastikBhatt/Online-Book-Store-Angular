package com.cg.bookstore.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bookstore.beans.Books;
import com.cg.bookstore.exception.BookISBNNotFoundException;
import com.cg.bookstore.services.BookstoreServices;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class BookstoreServicesController {
	@Autowired
	BookstoreServices bookstoreServices;
	
	@RequestMapping(value= {"/acceptBookDetails"}, method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE
			)
	public ResponseEntity<String> acceptAssociateDetails(@ModelAttribute Books book) {
		book = bookstoreServices.acceptBookDetails(book);
		return new ResponseEntity<String>("Book details successfully added associate ID : "+book.getISBN(), HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/getAllBookDetails"}, method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json"
			)
	public ResponseEntity<List<Books>> getAssociateDetailsPathParam() {
		return new ResponseEntity<List<Books>>(bookstoreServices.getAllBookDetails(), HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/getBookDetails/{bookISBN}"}, method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json"
			)
	public ResponseEntity<Books> getBookDetailsPathParam(@PathVariable(value="bookISBN") String bookISBN) throws BookISBNNotFoundException {
		return new ResponseEntity<Books>(bookstoreServices.getBookDetails(bookISBN), HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/removeBookDetails/{bookISBN}"}, method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json"
			)
	public ResponseEntity<String> removeBookDetailsPathParam(@PathVariable(value="bookISBN") String bookISBN) throws BookISBNNotFoundException {
		bookstoreServices.removeBookDetails(bookISBN);
		return new ResponseEntity<String>("Book details successfully updated for ISBN: "+bookISBN, HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/updateBookDetails"}, method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE,
			headers="Accept=application/json"
			)
	public ResponseEntity<String> updateBookDetailsPathParam(@ModelAttribute Books book) throws BookISBNNotFoundException {
		bookstoreServices.removeBookDetails(book.getISBN());
		book = bookstoreServices.acceptBookDetails(book);
		return new ResponseEntity<String>("Book details successfully updated for ISBN: "+book.getISBN(), HttpStatus.OK);
	}
}
