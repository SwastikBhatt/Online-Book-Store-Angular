package com.cg.bookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgOnlineBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgOnlineBookingSystemApplication.class, args);
	}

}
