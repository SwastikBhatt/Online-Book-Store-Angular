package com.cg.bookstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Books;
import com.cg.bookstore.daoservices.BookstoreDAO;
import com.cg.bookstore.exception.BookISBNAlreadyExistsException;
import com.cg.bookstore.exception.BookISBNNotFoundException;
@Component("bookServices")
public class BookstoreServicesImpl implements BookstoreServices{
	@Autowired
	private BookstoreDAO bookstoreDAO;
	@Override
	public Books acceptBookDetails(Books book) {
		return bookstoreDAO.save(book);
	}

	@Override
	public List<Books> getAllBookDetails() {
		return bookstoreDAO.findAll();
	}

	@Override
	public Books removeBookDetails(String bookISBN) throws BookISBNNotFoundException {
		if(getBookDetails(bookISBN)!=null)
		{
			Books book=getBookDetails(bookISBN);
			bookstoreDAO.delete(book);
			return book;
		}
		else
			throw new BookISBNNotFoundException("Book Details was not found");
	}

	@Override
	public Books getBookDetails(String bookISBN) throws BookISBNNotFoundException {
		return bookstoreDAO.findById(bookISBN).orElseThrow(()->new BookISBNNotFoundException("The BOOKISBN number is incorrect"));
	}

	@Override
	public Books updateBookDetails(Books book) throws BookISBNNotFoundException {
		if(getBookDetails(book.getISBN())!=null)
		{
			removeBookDetails(book.getISBN());
			Books bookCopy=acceptBookDetails(book);
			return bookCopy;
		}
		return null;
	}
	
}
