package com.cg.bookstore.services;

import java.util.List;

import com.cg.bookstore.beans.Books;
import com.cg.bookstore.exception.BookISBNAlreadyExistsException;
import com.cg.bookstore.exception.BookISBNNotFoundException;

public interface BookstoreServices {
	Books acceptBookDetails(Books book);
	List<Books> getAllBookDetails();

	Books removeBookDetails(String bookISBN) throws BookISBNNotFoundException;
	Books getBookDetails(String bookISBN)throws BookISBNNotFoundException;
	Books updateBookDetails(Books book)throws BookISBNNotFoundException;
}
